export default function Sidebar() {
  return (
    <div className="sidebar">
      <h3>About Community</h3>
      <p>This is a demo Reddit sidebar.</p>
      <p>Community rules • Moderators • FAQ</p>
    </div>
  );
}
